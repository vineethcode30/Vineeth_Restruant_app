package com.example.hotel_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Orders : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orders)
    }
}